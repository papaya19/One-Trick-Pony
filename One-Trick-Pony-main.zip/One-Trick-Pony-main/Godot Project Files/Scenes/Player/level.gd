extends Node2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	$Player.position = Global.screen_size / 2
	$CanvasLayer/BlackHole.position.x = randi_range(0, Global.screen_size.x)
	$CanvasLayer/BlackHole.position.y = randi_range(0, Global.screen_size.y)


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
